module.exports = {
    mongoURL: "mongodb+srv://afsan123:afsan786@@course-pqbno.mongodb.net/test?retryWrites=true&w=majority",
    secret: "mystrongsecret"
};




